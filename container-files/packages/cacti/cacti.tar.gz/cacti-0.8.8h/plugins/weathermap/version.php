<?php
require_once "lib/Weathermap.class.php";

print $WEATHERMAP_VERSION;

// vim:ts=4:sw=4:
