<?php

// To show the Discovery Tab, set to TRUE
// To show it as a menu option, set to FALSE

$discovery_tab = TRUE;

?>